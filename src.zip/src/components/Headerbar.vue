<template>
  <div>
    <h1>指标监控平台</h1>
  </div>
</template>

<script>
export default {
  name: 'Header'
}
</script>

<style scoped>

div {
  height: 70px;
  width: 160px;
  background-color: #ffffff;
  opacity: 0.9;
  margin-top: 40px;
  border-radius: 0 16px 16px 0;
}

h1 {
  line-height: 70px;
  padding: 0 30px;
  font-size: 16px;
  color: #107957;
}
</style>
